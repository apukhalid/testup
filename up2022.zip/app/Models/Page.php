<?php

 
namespace App\Models;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Page extends Model {

   public static function insertData($data){

     // $value=DB::table('category')->where('id', $data['id'])->get();
    
         DB::table('category')->insert($data);
      
   }

}